import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;

public class AddCityInfo extends JFrame {
    private JTextField cityNameField;
    private JTextArea descriptionArea;
    private File[] selectedImages;

    public AddCityInfo() {
        setTitle("➕ Add City Information");
        setSize(600, 500);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.decode("#EEF5FF"));

        JLabel nameLabel = new JLabel("City Name:");
        nameLabel.setBounds(30, 30, 100, 25);
        add(nameLabel);

        cityNameField = new JTextField();
        cityNameField.setBounds(140, 30, 200, 25);
        add(cityNameField);

        JLabel descLabel = new JLabel("Description:");
        descLabel.setBounds(30, 70, 100, 25);
        add(descLabel);

        descriptionArea = new JTextArea();
        descriptionArea.setBounds(140, 70, 1000, 300);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(descriptionArea);

        JButton chooseImagesBtn = new JButton("Choose Images (Max 5)");
        chooseImagesBtn.setBounds(350, 400, 200, 30);
        add(chooseImagesBtn);

        JButton saveBtn = new JButton("Save");
        saveBtn.setBounds(360, 450, 100, 30);
        add(saveBtn);

        chooseImagesBtn.addActionListener(e -> chooseImages());
        saveBtn.addActionListener(e -> saveCityInfo());

        setVisible(true);
    }

    private void chooseImages() {
        JFileChooser chooser = new JFileChooser();
        chooser.setMultiSelectionEnabled(true);
        chooser.setDialogTitle("Select 1 to 5 Images");

        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File[] files = chooser.getSelectedFiles();

            if (files.length < 1 || files.length > 5) {
                JOptionPane.showMessageDialog(this, "Please select at least 1 and at most 5 images.");
                selectedImages = null;
            } else {
                selectedImages = files;
                JOptionPane.showMessageDialog(this, files.length + " image(s) selected successfully.");
            }
        }
    }

    private void saveCityInfo() {
        String name = cityNameField.getText().trim();
        String desc = descriptionArea.getText().trim();

        if (name.isEmpty() || desc.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in city name and description.");
            return;
        }

        if (selectedImages == null || selectedImages.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select at least 1 image.");
            return;
        }

        Connection conn = null;
        PreparedStatement stmtCity = null;
        PreparedStatement stmtImage = null;
        ResultSet generatedKeys = null;

        try {
            conn = HistoryDatabase.getConnection();
            conn.setAutoCommit(false); // begin transaction

            // Insert city info
            stmtCity = conn.prepareStatement(
                "INSERT INTO city_info (city_name, description) VALUES (?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );
            stmtCity.setString(1, name);
            stmtCity.setString(2, desc);
            stmtCity.executeUpdate();

            generatedKeys = stmtCity.getGeneratedKeys();
            int cityId = -1;
            if (generatedKeys.next()) {
                cityId = generatedKeys.getInt(1);
            }

            if (cityId == -1) throw new Exception("Failed to retrieve city_id.");

            // Insert images
            stmtImage = conn.prepareStatement("INSERT INTO city_images (city_id, image_blob) VALUES (?, ?)");
            for (File imgFile : selectedImages) {
                if (imgFile.exists()) {
                    FileInputStream fis = new FileInputStream(imgFile.getAbsolutePath());
                    stmtImage.setInt(1, cityId);
                    stmtImage.setBinaryStream(2, fis, (int) imgFile.length());
                    stmtImage.executeUpdate();
                    fis.close();
                } else {
                    throw new FileNotFoundException("Image not found: " + imgFile.getAbsolutePath());
                }
            }

            conn.commit(); // end transaction
            JOptionPane.showMessageDialog(this, "City info and images saved successfully!");
            dispose();

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage());

        } finally {
            HistoryDatabase.closeResultSet(generatedKeys);
            HistoryDatabase.closeStatement(stmtCity);
            HistoryDatabase.closeStatement(stmtImage);
            HistoryDatabase.closeConnection(conn);
        }
    }
}
