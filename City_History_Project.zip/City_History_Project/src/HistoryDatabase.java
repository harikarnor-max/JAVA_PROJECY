import java.sql.*;

public class HistoryDatabase {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/historyapp";
    private static final String DB_USER = "root";        // Replace with your MySQL username
    private static final String DB_PASSWORD = "surya123.com";        // Replace with your password if any

    // Get connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    // Close connection
    public static void closeConnection(Connection conn) {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Close statement
    public static void closeStatement(Statement stmt) {
        try {
            if (stmt != null) stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Close result set
    public static void closeResultSet(ResultSet rs) {
        try {
            if (rs != null) rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
