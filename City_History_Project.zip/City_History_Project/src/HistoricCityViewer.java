import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject; // Make sure org.json jar is on the classpath

public class HistoricCityViewer extends JFrame {
    private JTextField cityInput;
    private JTextArea descriptionArea;
    private JLabel imageLabel;
    private JEditorPane mapPane;           // ✅ now created in constructor
    private Timer sliderTimer;
    private final List<ImageIcon> imageIcons = new ArrayList<>();
    private int currentImageIndex = 0;

    // ✅ Your OpenWeatherMap API key
    private static final String WEATHER_API_KEY = "f1da39458c7d8ede85e13bb3fae95838";

    public HistoricCityViewer() {
        setTitle("🏛️ Historic City Info Viewer");
        setSize(1000, 800);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.decode("#F9F5EB"));

        JLabel heading = new JLabel("Enter City Name:");
        heading.setBounds(50, 30, 150, 25);
        heading.setFont(new Font("Arial", Font.BOLD, 14));
        add(heading);

        cityInput = new JTextField();
        cityInput.setBounds(200, 30, 200, 25);
        add(cityInput);

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(420, 30, 100, 25);
        add(searchBtn);

        JButton showMapBtn = new JButton("Open in Google Maps");
        showMapBtn.setBounds(550, 30, 200, 25);
        add(showMapBtn);

        JButton weatherBtn = new JButton("Show Weather");
        weatherBtn.setBounds(770, 30, 150, 25);
     
        add(weatherBtn);

        imageLabel = new JLabel();
        imageLabel.setBounds(250, 70, 450, 250); // a bit larger for clarity
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(imageLabel);

        // ✅ Map pane (HTML) — was missing (caused NPE)
        mapPane = new JEditorPane();
        
        mapPane.setEditable(false);
        mapPane.setContentType("text/html"); // necessary to render iframe/html
        mapPane.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);
        mapPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(mapPane);

        // Description with scrollbar
        descriptionArea = new JTextArea();
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setEditable(false);
        descriptionArea.setFont(new Font("Serif", Font.PLAIN, 16));
        JScrollPane descScroll = new JScrollPane(descriptionArea);
        descScroll.setBounds(50, 340, 890, 330);
        descScroll.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(descScroll);

        JButton addCityBtn = new JButton("Add City Info");
        addCityBtn.setBounds(200, 700, 150, 30);
        add(addCityBtn);

        JButton hotelsBtn = new JButton("View Hotels");
        hotelsBtn.setBounds(370, 700, 150, 30);
        add(hotelsBtn);

        JButton trainBtn = new JButton("Book Train");
        trainBtn.setBounds(540, 700, 150, 30);
        add(trainBtn);

        // Actions
        searchBtn.addActionListener(e -> fetchCityInfo());
        addCityBtn.addActionListener(e -> new AddCityInfo());

        showMapBtn.addActionListener(e -> {
            String city = cityInput.getText().trim();
            if (city.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a city name first.");
                return;
            }
            try {
                String cityQuery = URLEncoder.encode(city, "UTF-8");
                String mapUrl = "https://www.google.com/maps?q=" + cityQuery;
                Desktop.getDesktop().browse(new URI(mapUrl));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to open map: " + ex.getMessage());
            }
        });

        hotelsBtn.addActionListener(e -> {
            String city = cityInput.getText().trim();
            if (city.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a city name first.");
                return;
            }
            try {
                String cityQuery = URLEncoder.encode(city, "UTF-8");
                String hotelsUrl = "https://www.google.com/maps/search/hotels+in+" + cityQuery;
                Desktop.getDesktop().browse(new URI(hotelsUrl));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to open hotels list: " + ex.getMessage());
            }
        });

        trainBtn.addActionListener(e -> {
            try {
                Desktop.getDesktop().browse(new URI("https://www.irctc.co.in/nget/train-search"));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to open IRCTC: " + ex.getMessage());
            }
        });

        // Weather + inline map update
        weatherBtn.addActionListener(e -> {
            String city = cityInput.getText().trim();
            if (city.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a city name first.");
                return;
            }
            fetchWeather();
            showGoogleMap(city);
        });

        setVisible(true);
    }

    private void fetchCityInfo() {
        String city = cityInput.getText().trim();
        if (city.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a city name.");
            return;
        }

        Connection conn = null;
        PreparedStatement stmtCity = null;
        PreparedStatement stmtImages = null;
        ResultSet rsCity = null;
        ResultSet rsImages = null;

        try {
            conn = HistoryDatabase.getConnection();

            // ✅ case-insensitive + trimmed match
            stmtCity = conn.prepareStatement(
                "SELECT city_id, description FROM city_info WHERE LOWER(TRIM(city_name)) = LOWER(TRIM(?))"
            );
            stmtCity.setString(1, city);
            rsCity = stmtCity.executeQuery();

            if (rsCity.next()) {
                int cityId = rsCity.getInt("city_id");
                String description = rsCity.getString("description");
                descriptionArea.setText("City: " + city + "\n\n" + (description == null ? "" : description));
                showGoogleMap(city);

                stmtImages = conn.prepareStatement("SELECT image_blob FROM city_images WHERE city_id = ?");
                stmtImages.setInt(1, cityId);
                rsImages = stmtImages.executeQuery();

                imageIcons.clear();
                while (rsImages.next()) {
                    byte[] imageBytes = rsImages.getBytes("image_blob");
                    if (imageBytes != null && imageBytes.length > 0) {
                        ImageIcon icon = new ImageIcon(imageBytes);
                        Image scaled = icon.getImage().getScaledInstance(
                                imageLabel.getWidth(), imageLabel.getHeight(), Image.SCALE_SMOOTH);
                        imageIcons.add(new ImageIcon(scaled));
                    }
                }

                if (imageIcons.isEmpty()) {
                    imageLabel.setIcon(null);
                    imageLabel.setText("No images found.");
                    if (sliderTimer != null) sliderTimer.stop();
                } else {
                    imageLabel.setText(null);
                    currentImageIndex = 0;
                    startImageSlider();
                }
            } else {
                descriptionArea.setText("No historical info found for: " + city);
                imageLabel.setIcon(null);
                imageLabel.setText("No images.");
                mapPane.setText("");
                if (sliderTimer != null) sliderTimer.stop();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data: " + ex.getMessage());
        } finally {
            HistoryDatabase.closeResultSet(rsImages);
            HistoryDatabase.closeResultSet(rsCity);
            HistoryDatabase.closeStatement(stmtImages);
            HistoryDatabase.closeStatement(stmtCity);
            HistoryDatabase.closeConnection(conn);
        }
    }

    private void showGoogleMap(String city) {
        try {
            String cityQuery = URLEncoder.encode(city, "UTF-8");
            String mapEmbedUrl = "https://www.google.com/maps?q=" + cityQuery + "&output=embed";

            // Simple HTML with iframe
            String iframeHTML =
                    "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body style='margin:0;'>"
                            + "<iframe width='100%' height='100%' style='border:0' loading='lazy' "
                            + "referrerpolicy='no-referrer-when-downgrade' allowfullscreen "
                            + "src='" + mapEmbedUrl + "'></iframe>"
                            + "</body></html>";

            mapPane.setText(iframeHTML);
            mapPane.setCaretPosition(0);
        } catch (Exception e) {
            mapPane.setText("<html><body>Unable to load map.</body></html>");
        }
    }

    // OpenWeatherMap current weather
    private void fetchWeather() {
        String city = cityInput.getText().trim();
        if (city.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a city name first.");
            return;
        }

        HttpURLConnection http = null;
        BufferedReader reader = null;
        try {
            String cityQuery = URLEncoder.encode(city, "UTF-8");
            String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + cityQuery
                    + "&appid=" + WEATHER_API_KEY + "&units=metric";

            URL url = new URL(urlString);
            http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("GET");
            http.setConnectTimeout(8000);
            http.setReadTimeout(8000);

            int code = http.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? http.getInputStream() : http.getErrorStream();

            reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);

            JSONObject obj = new JSONObject(json.toString());
            if (obj.has("cod") && obj.getInt("cod") != 200) {
                String msg = obj.optString("message", "Unknown error");
                throw new RuntimeException(msg);
            }

            String weather = obj.getJSONArray("weather").getJSONObject(0).getString("description");
            double temp = obj.getJSONObject("main").getDouble("temp");
            double feelsLike = obj.getJSONObject("main").getDouble("feels_like");

            JOptionPane.showMessageDialog(this,
                    "Weather in " + city + ":\n" +
                    "Condition: " + weather + "\n" +
                    "Temperature: " + temp + "°C\n" +
                    "Feels Like: " + feelsLike + "°C");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Unable to fetch weather: " + ex.getMessage());
        } finally {
            try { if (reader != null) reader.close(); } catch (IOException ignored) {}
            if (http != null) http.disconnect();
        }
    }

    private void startImageSlider() {
        if (sliderTimer != null) sliderTimer.stop();
        if (imageIcons.isEmpty()) return;

        imageLabel.setIcon(imageIcons.get(0));
        sliderTimer = new Timer(3000, e -> {
            currentImageIndex = (currentImageIndex + 1) % imageIcons.size();
            imageLabel.setIcon(imageIcons.get(currentImageIndex));
        });
        sliderTimer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HistoricCityViewer::new);
    }
}
